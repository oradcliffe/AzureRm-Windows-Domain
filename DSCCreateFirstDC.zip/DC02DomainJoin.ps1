﻿configuration DomainJoin
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [string]$MachineName,

        [Int]$RetryCount=10,
        [Int]$RetryIntervalSec=30

    ) 
    
    Import-DscResource -ModuleName xComputerManagement, xPendingReboot, xActiveDirectory
    [System.Management.Automation.PSCredential ]$Credential = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }

        xComputer DomainJoin
        {
            DomainName = $DomainName
            Credential = $Credential
            DependsOn = [xWaitForADDomain]DscForestWait
        }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]DomainJoin"
        }
   }
} 