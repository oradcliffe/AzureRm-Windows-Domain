﻿configuration DomainJoin
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [string]$MachineName

    ) 
    
    Import-DscResource -ModuleName xComputerManagement, xPendingReboot
    [System.Management.Automation.PSCredential ]$Credential = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        xComputer DomainJoin
        {
            Name = $MachineName
            DomainName = $DomainName
            Credential = $Credential
        }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]DomainJoin"
        }
   }
} 