﻿configuration FS01
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xPendingReboot, xSmbShare, cNtfsAccessControl
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {

        $rootDirPath = "$env:SystemDrive\shares"
        $itGroupName = 'G_IT'
        $groupNamePrefix = 'G_'
        $configdata = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        $groups = ($configdata.dept | Select-Object -Unique)

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        File publicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = "$rootDirPath\Public"
        }

        foreach ($group in $groups) {
            File "groupDir_$group"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$rootDirPath\$group"
            }
        }

        xComputer JoinDomain 
        { 
            Name = $env:ComputerName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
            DependsOn = '[xPendingReboot]Reboot1'
        }
        
        cNtfsPermissionEntry publicDir_FullControl
        {
            Ensure = 'Present'
            Path = "$rootDirPath\Public"
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        cNtfsPermissionEntry publicDir_Modify
        {
            Ensure = 'Present'
            Path = "$rootDirPath\Public"
            Principal = 'Domain Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'Modify'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        foreach ($group in $groups) {
            if ($group -eq 'IT'){
                cNtfsPermissionEntry "groupDir_$group"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$group"
                        Principal = $itGroupName
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$group"
                    }
            }
            else {
                cNtfsPermissionEntry "groupDir_Modify_$group"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$group"
                        Principal = "$groupNamePrefix$group"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'Modify'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$group"
                    }
                cNtfsPermissionEntry "groupDir_fullControl_$group"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$group"
                        Principal = "$itGroupName"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$group"
                    }
                }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = "$rootDirPath\Public"
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]publicDir'
        }

        foreach ($group in $groups) {
            if ($group -eq 'IT'){
                    xSmbShare "private_$group"
                {
                    Ensure = 'Present'
                    Name   = "$group"
                    Path = "$rootDirPath\$group"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $group"
                    DependsOn = "[File]groupDir_$group"
                }
            }
            else {
                xSmbShare "private_$group"
                {
                    Ensure = 'Present'
                    Name   = "$group"
                    Path = "$rootDirPath\$group"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$group"
                    Description = "This is a private share for $group"
                    DependsOn = "[File]groupDir_$group"
                }
            }
        }
    }
}