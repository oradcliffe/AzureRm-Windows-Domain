# Description

This resource is used to create, edit or remove standalone or domain based DFS
namespaces. When the server is the last server in the namespace, the namespace
itself will be removed.
