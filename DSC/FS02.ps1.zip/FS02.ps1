﻿configuration FS02
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [String]$fs01ComputerName,

        [Parameter(Mandatory)]
        [String]$fs02ComputerName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xPendingReboot, xSmbShare, cNtfsAccessControl, xDFS
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {

        $rootDirPath = "$env:SystemDrive\shares"
        $itGroupName = 'G_IT'
        $groupNamePrefix = 'G_'

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        File publicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = "$rootDirPath\Public"
        }

        foreach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            File "groupDir_$RootOU"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$rootDirPath\$RootOU"
            }
        }

        xComputer JoinDomain 
        { 
            Name = $env:ComputerName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
            DependsOn = '[xPendingReboot]Reboot1'
        }
        
        cNtfsPermissionEntry publicDir_FullControl
        {
            Ensure = 'Present'
            Path = "$rootDirPath\Public"
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        cNtfsPermissionEntry publicDir_Modify
        {
            Ensure = 'Present'
            Path = "$rootDirPath\Public"
            Principal = 'Domain Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'Modify'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        foreach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            if ($RootOU -eq 'IT'){
                cNtfsPermissionEntry "groupDir_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = $itGroupName
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
            }
            else {
                cNtfsPermissionEntry "groupDir_Modify_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = "$groupNamePrefix$RootOU"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'Modify'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
                cNtfsPermissionEntry "groupDir_fullControl_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = "$itGroupName"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
                }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = "$rootDirPath\Public"  
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]publicDir'
        }

        foreach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            if ($RootOU -eq 'IT'){
                    xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "$RootOU"
                    Path = "$rootDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
            else {
                xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "$RootOU"
                    Path = "$rootDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$RootOU"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
        }

        ###Create Namespaces###

        xDFSNamespaceServerConfiguration DFSNamespaceConfig
        {
            IsSingleInstance          = 'Yes'
            UseFQDN                   = $false
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_FS01
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = "\\$fs01ComputerName\Public"
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_FS02
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = "\\$fs02ComputerName\Public"
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            xDFSNamespaceRoot "DFSNamespaceRoot_FS01_$RootOU"
            {
                Path                 = "\\$DomainName\$RootOU"
                TargetPath           = "\\$fs01ComputerName\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[xSMBShare]Private_$RootOU"
            }

            xDFSNamespaceRoot "DFSNamespaceRoot_FS02_$RootOU"
            {
                Path                 = "\\$DomainName\$RootOU"
                TargetPath           = "\\$fs02ComputerName\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[xSMBShare]Private_$RootOU"
            }
        }
        

        ###Start DFS Replication configuration###

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = "$fs01ComputerName", "$fs02ComputerName"
            Folders = 'Public'
            Topology = 'Fullmesh'
            ContentPaths = "$rootDirPath\Public"
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_FS01',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_FS02'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {        
        xDFSReplicationGroup "Replication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = "$fs01ComputerName", "$fs02ComputerName"
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "$rootDirPath\$RootOU"
                DomainName = $DomainName
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[xDFSNamespaceRoot]DFSNamespaceRoot_FS01_$RootOU",
                            "[xDFSNamespaceRoot]DFSNamespaceRoot_FS02_$RootOU"
            }
        }
    }
}