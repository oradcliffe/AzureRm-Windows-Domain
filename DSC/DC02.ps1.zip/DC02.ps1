﻿configuration DC02
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    
    Import-DscResource -ModuleName ActiveDirectoryDsc, NetworkingDsc, ComputerManagementDsc
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }
        
        WindowsFeature ADDSInstall 
        { 
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }

        MSFT_ADDomain SecondDC 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        DSC_PendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[MSFT_ADDomain]SecondDC'
        }

        #xADRecycleBin RecycleBin
        #{
        #   EnterpriseAdministratorCredential = $DomainCreds
        #   ForestFQDN = $DomainName
        #   DependsOn = '[DSC_PendingReboot]Reboot1'
        #}

# This Script ParametersFile is for troubleshooting passing credentials into the second domain controller from the ARM template
# It shows that when passing credentials in from the DSC resource in the ARM template, if you use the ProtectedSettingsRef, the DSC
# resource does not get the correct password

#        Script ParametersFile 
#        {
#            GetScript = {
#                @{ Result = (Get-Content 'C:\creds.txt') }
#            }
#            TestScript = {
#                Test-Path 'C:\creds.txt'
#            }
#            SetScript = {
#                "Domain: $using:DomainName" | Out-File 'C:\creds.txt'
#                "Admincreds.username: $($using:Admincreds.UserName)" | Out-File 'C:\creds.txt' -Append
#                "Admincreds.password.length: $($using:Admincreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
#                "Domaincreds.username: $($using:DomainCreds.UserName)" | Out-File 'C:\creds.txt' -Append
#                "Domaincreds.password.length: $($using:DomainCreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
#            }
#        }

                ### OUs ###
        $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
        $depts = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        $DependsOn_OU = @()

        ForEach ($dept in $depts.dept | Select-Object -Unique) {

            MSFT_ADOrganizationalUnit "OU_$dept"
            {
                Name = $dept
                Path = $DomainRoot
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for $dept"
                Credential = $DomainCreds
                Ensure = 'Present'
                DependsOn = '[DSC_PendingReboot]Reboot1'
            }

            ForEach ($ChildOU in $ConfigurationData.NonNodeData.ChildOUs) {
                
                MSFT_ADOrganizationalUnit "OU_$($dept)_$ChildOU"
                {
                    Name = $ChildOU
                    Path = "OU=$dept,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Credential = $DomainCreds
                    Ensure = 'Present'
                    DependsOn = "[MSFT_ADOrganizationalUnit]OU_$dept",
                                '[DSC_PendingReboot]Reboot1'
                }

                $DependsOn_OU += "[MSFT_ADOrganizationalUnit]OU_$($dept)_$ChildOU"
            }

        }


        ### USERS ###
        $DependsOn_User = @()
        $Users = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        ForEach ($User in $Users) {

            MSFT_ADUser "NewADUser_$($User.UserName)"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = $User.UserName
                UserPrincipalName = "$($User.Username)@$($DomainName)" 
                GivenName = $User.Givenname
                Surname = $User.Surname
                JobTitle = $User.Title
                Path = "OU=Users,OU=$($User.Dept),$DomainRoot"
                Enabled = $true
                Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                DependsOn = $DependsOn_OU,
                            '[DSC_PendingReboot]Reboot1'
            }
            $DependsOn_User += "[MSFT_ADUser]NewADUser_$($User.UserName)"
        }

        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            MSFT_ADUser "NewADUser_$_"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = "TestUser$_"
                Enabled = $false  # Must specify $false if disabled and no password
                DependsOn = '[DSC_PendingReboot]Reboot1'
            }

        }


        ### GROUPS ###
        ForEach ($group in $depts.dept | Select-Object -Unique) {
            MSFT_ADGroup "NewADGroup_$group"
            {
                GroupName = "G_$group"
                GroupScope = 'Global'
                Description = "Global group for $group"
                Category = 'Security'
                Members = ($Users | Where-Object {$_.Dept -eq $group}).UserName
                Path = "OU=Groups,OU=$group,$DomainRoot"
                Ensure = 'Present'
                DependsOn = $DependsOn_User,
                            '[DSC_PendingReboot]Reboot1'
            }
        }

        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            MSFT_ADGroup "NewADGroup_$_"
            {
                GroupName = "TestGroup$_"
                GroupScope = 'Global'
                Category = 'Security'
                Members = "TestUser$_"
                Ensure = 'Present'
                DependsOn = "[MSFT_ADUser]NewADUser_$_",
                            '[DSC_PendingReboot]Reboot1'
            }

        }

         ###Add IT to Domain Admins###
        
        MSFT_ADGroup addIT
        {
            GroupName = 'Domain Admins'
            MembersToInclude = 'G_IT'
            Ensure = 'Present'
        }

   }
} 