﻿configuration CreateSecondDC
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }
        
        WindowsFeature ADDSInstall 
        { 
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }

        xADDomainController SecondDC 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xADDomainController]SecondDC'
        }

        xADRecycleBin RecycleBin
        {
           EnterpriseAdministratorCredential = $DomainCreds
           ForestFQDN = $DomainName
           DependsOn = '[xPendingReboot]Reboot1'
        }

# This Script ParametersFile is for troubleshooting passing credentials into the second domain controller from the ARM template
# It shows that when passing credentials in from the DSC resource in the ARM template, if you use the ProtectedSettingsRef, the DSC
# resource does not get the correct password

        Script ParametersFile 
        {
            GetScript = {
                @{ Result = (Get-Content 'C:\creds.txt') }
            }
            TestScript = {
                Test-Path 'C:\creds.txt'
            }
            SetScript = {
                "Domain: $using:DomainName" | Out-File 'C:\creds.txt'
                "Admincreds.username: $($using:Admincreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Admincreds.password.length: $($using:Admincreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.username: $($using:DomainCreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.password.length: $($using:DomainCreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
            }
        }

                ### OUs ###
        $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
        $DependsOn_OU = @()

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {

            xADOrganizationalUnit "OU_$RootOU"
            {
                Name = $RootOU
                Path = $DomainRoot
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for $RootOU"
                Credential = $DomainCreds
                Ensure = 'Present'
                DependsOn = '[xADRecycleBin]RecycleBin'
            }

            ForEach ($ChildOU in $ConfigurationData.NonNodeData.ChildOUs) {
                
                xADOrganizationalUnit "OU_$($RootOU)_$ChildOU"
                {
                    Name = $ChildOU
                    Path = "OU=$RootOU,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Credential = $DomainCreds
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]OU_$RootOU"
                }

                $DependsOn_OU += "[xADOrganizationalUnit]OU_$($RootOU)_$ChildOU"
            }

        }


        ### USERS ###
        $DependsOn_User = @()
        $Users = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        ForEach ($User in $Users) {

            xADUser "NewADUser_$($User.UserName)"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = $User.UserName
                UserPrincipalName = $User.UPN
                GivenName = $User.Givenname
                Surname = $User.Surname
                JobTitle = $User.Title
                Path = "OU=Users,OU=$($User.Dept),$DomainRoot"
                Enabled = $true
                Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                DependsOn = $DependsOn_OU
            }
            $DependsOn_User += "[xADUser]NewADUser_$($User.UserName)"
        }

        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            xADUser "NewADUser_$_"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = "TestUser$_"
                Enabled = $false  # Must specify $false if disabled and no password
                DependsOn = '[xADRecycleBin]RecycleBin'
            }

        }


        ### GROUPS ###
        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            xADGroup "NewADGroup_$RootOU"
            {
                GroupName = "G_$RootOU"
                GroupScope = 'Global'
                Description = "Global group for $RootOU"
                Category = 'Security'
                Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = $DependsOn_User
            }
        }

        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            xADGroup "NewADGroup_$_"
            {
                GroupName = "TestGroup$_"
                GroupScope = 'Global'
                Category = 'Security'
                Members = "TestUser$_"
                Ensure = 'Present'
                DependsOn = "[xADUser]NewADUser_$_"
            }

        }

         ###Add IT to Domain Admins###
        
        xADGroup addIT
        {
            GroupName = 'Domain Admins'
            MembersToInclude = 'G_IT'
            Ensure = 'Present'
            DependsOn = '[xADUser]NewADGroup_IT'
        }
   }
} 