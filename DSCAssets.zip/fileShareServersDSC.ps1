﻿configuration fileShareConfig
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xDFS, xPendingReboot
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

# This Script ParametersFile is for troubleshooting passing params into the this DSC config from the ARM template
# It shows that when passing credentials in from the DSC resource in the ARM template, if you use the ProtectedSettingsRef, the DSC
# resource does not get the correct password

        Script ParametersFile 
        {
            GetScript = {
                @{ Result = (Get-Content 'C:\creds.txt') }
            }
            TestScript = {
                Test-Path 'C:\creds.txt'
            }
            SetScript = {
                "Domain: $using:DomainName" | Out-File 'C:\creds.txt'
                "machineName: $using:machineName" | Out-File 'C:\creds.txt' -Append
                "Admincreds.username: $($using:Admincreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Admincreds.password.length: $($using:Admincreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.username: $($using:DomainCreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.password.length: $($using:DomainCreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
            }
        }

        xComputer JoinDomain 
        { 
            Name = $env:ComputerName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
            DependsOn = '[xComputer]JoinDomain'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
            DependsOn = '[xPendingReboot]Reboot1'
        }
        
        ###Create shared folders###

        xDFSNamespaceRoot DFSNamespaceRoot_Public_FS01
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\GTM-FS01\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_FS02
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\GTM-FS02\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Private_FS01
        {
            Path                 = "\\$DomainName\Private"
            TargetPath           = '\\GTM-FS01\Private'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Private folder for company groups'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Private_FS02
        {
            Path                 = "\\$DomainName\Private"
            TargetPath           = '\\GTM-FS02\Private'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Private folder for company groups'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            xDFSNamespaceRoot DFSNamespaceRoot_Private_FS01_$RootOU
            {
                Path                 = "\\$DomainName\Private\$RootOU"
                TargetPath           = "\\GTM-FS01\Private\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS01'
            }

            xDFSNamespaceRoot DFSNamespaceRoot_Private_FS02_$RootOU
            {
                Path                 = "\\$DomainName\Private\$RootOU"
                TargetPath           = "\\GTM-FS02\Private\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS02'
            }
        

        ###Start DFS Replication configuration###

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = 'GTM-FS01', 'GTM-FS02'
            Folders = 'Public'
            Topology = 'Fullmesh'
            ContentPaths = '\\GTM-FS01\Public', '\\GTM-FS02\Public'
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_FS01',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_FS02'
        }

        xDFSReplicationGroup PrivateReplication
        {
            GroupName = 'PrivateFiles'
            Description = 'Private folder to hold group folders'
            Ensure = 'Present'
            Members = 'GTM-FS01', 'GTM-FS02'
            Folders = 'Private'
            Topology = 'Fullmesh'
            ContentPaths = '\\GTM-FS01\Private', '\\GTM-FS02\Private'
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS01',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS02'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {        
        xDFSReplicationGroup "PrivateReplication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = 'GTM-FS01', 'GTM-FS02'
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "\\GTM-FS01\Private\$RootOU", "\\GTM-FS02\Private\$RootOU"
                DomainName = $DomainName
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS01_$RootOU",
                            "[xDFSNamespaceRoot]DFSNamespaceRoot_Private_FS01_$RootOU"
            }
        }
   }
} 