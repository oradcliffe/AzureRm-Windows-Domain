﻿configuration fileShareConfig
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds,

        [Parameter(Mandatory)]
        [String]$machineName
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xDFS, xPendingReboot
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

# This Script ParametersFile is for troubleshooting passing params into the this DSC config from the ARM template
# It shows that when passing credentials in from the DSC resource in the ARM template, if you use the ProtectedSettingsRef, the DSC
# resource does not get the correct password

        Script ParametersFile 
        {
            GetScript = {
                @{ Result = (Get-Content 'C:\creds.txt') }
            }
            TestScript = {
                Test-Path 'C:\creds.txt'
            }
            SetScript = {
                "Domain: $using:DomainName" | Out-File 'C:\creds.txt'
                "machineName: $using:machineName" | Out-File 'C:\creds.txt' -Append
                "Admincreds.username: $($using:Admincreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Admincreds.password.length: $($using:Admincreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.username: $($using:DomainCreds.UserName)" | Out-File 'C:\creds.txt' -Append
                "Domaincreds.password.length: $($using:DomainCreds.Password.Length)" | Out-File 'C:\creds.txt' -Append
            }
        }

        xComputer JoinDomain 
        { 
            Name = $machineName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        File ShareDirectories
            {
                Ensure = 'Present'
                DestinationPath = 'c:\public\files'
                Type = 'Directory'
            }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            File "PrivateDirectory_$RootOU"
            {
                Ensure = 'Present'
                DestinationPath = "c:\private\$RootOU"
                Type = 'Directory'
            }
        }

        ###Start DFS configuration###
        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = 'GTM-FS01','GTM-FS02'
            Folders = 'files'
            Topology = 'Fullmesh'
            ContentPaths = 'c:\public\files'
            Domain = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]RSATDFSMgmtConInstall'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {        
        xDFSReplicationGroup "PrivateReplication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = 'GTM-FS01.gametimeor.priv','GTM-FS02.gametimeor.priv'
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "c:\private\$RootOU"
                Domain = $DomainName
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[WindowsFeature]RSATDFSMgmtConInstall"
            }
        }
   }
} 