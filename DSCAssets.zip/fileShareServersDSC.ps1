﻿configuration fileShareConfig
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xDFS, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        } 

        xComputer JoinDomain 
        { 
            Name = localhost
            DomainName = $DomainName
            Credential = $DomainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        File ShareDirectories
            {
                Ensure = 'Present'
                DestinationPath = 'c:\public\files'
                Type = 'Directory'
            }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
            File "PrivateDirectory_$RootOU"
            {
                Ensure = 'Present'
                DestinationPath = "c:\private\$RootOU"
                Type = 'Directory'
            }
        }

        ###Start DFS configuration###
        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = 'GTM-FS01.gametimeor.priv','GTM-FS02.gametimeor.priv'
            Folders = 'Files'
            Topology = 'Fullmesh'
            ContentPaths = 'c:\public\files'
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]RSATDFSMgmtConInstall'
        }

        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {        
        xDFSReplicationGroup "PrivateReplication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = 'GTM-FS01.gametimeor.priv','GTM-FS02.gametimeor.priv'
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "c:\private\$RootOU"
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[WindowsFeature]RSATDFSMgmtConInstall"
            }
        }
   }
} 