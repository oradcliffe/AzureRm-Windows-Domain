﻿configuration testfile
{
    # One can evaluate expressions to get the node list
    # E.g: $AllNodes.Where("Role -eq Web").NodeName
    node localhost
    {
        File Filedemo
        {
            Ensure          = "Present"
            DestinationPath = 'C:\testfile.txt'
            Contents = 'This file is a test file'
        }       
    }
}